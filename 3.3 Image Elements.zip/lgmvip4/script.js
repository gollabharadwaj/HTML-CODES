// Storing the value of the input field
let output = document.getElementById("output");

// To add the value one after the other
function display(num) {
  output.value += num;
}

// To calculate the result
function calculate() {
  try {
    const result = eval(output.value);
    output.value = result;
  } catch (err) {
    output.value = "Error";
  }
}

// To clear the output screen
function cl() {
  output.value = "";
}

// To delete the value one by one from the backside
function del() {
  output.value = output.value.slice(0, -1);
}

// Clear the output screen after clicking the equal button
document.querySelector(".equal").addEventListener("click", () => {
  calculate();
  setTimeout(cl, 1500); // Clear the output after 1.5 seconds
});
